<?php

$host = "veri taban� host name";    /* Host name */
$user = "kullan�c� ad�";         /* User */
$password = "�ifre";         /* Password */
$dbname = "veri taban� ismi";   /* Database name */

// Create connection
$con = mysqli_connect($host, $user, $password,$dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

